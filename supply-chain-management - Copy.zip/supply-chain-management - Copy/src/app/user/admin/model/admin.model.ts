export class Admin {
    id!: number;
    name!: string;
    email!: string;
    role!: string; // e.g., 'Admin', 'Production Manager'
  }
  