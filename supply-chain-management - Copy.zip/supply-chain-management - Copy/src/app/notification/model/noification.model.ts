export class Notification {
    id!: number;
    orderId!: number;
    message!: string;
    status!: string; // e.g., 'Unread', 'Read'
    createdAt!: Date;
    // order:;
  }
  